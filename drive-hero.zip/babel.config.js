module.exports = function (api) {
    return {
      plugins: ["@babel/plugin-transform-runtime","macros"],
    }
  }